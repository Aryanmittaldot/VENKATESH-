Upload index.html + assets folder to GitHub.
Meta Pixel ID: 1327465096016386
PageView fires on page load; Lead fires on Telegram button click.
Replace https://t.me/OCTOPUSBOSS with your actual Telegram link.
